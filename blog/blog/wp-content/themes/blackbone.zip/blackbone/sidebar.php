<aside class="sidebar-wrapper">
<?php

	dynamic_sidebar( "bb-sidebar-right" );

?>
<!--
	<div class="single-widget widget_search">
		<div class="widget-cont">
			<form class="search-form" role="search" method="get" action="http://localhost/wordpress/">
				<input id="search-form-5889e853e6137" class="search-field" placeholder="Search …" value="" name="s" type="search">
				<button class="search-submit" type="submit"></button>
			</form>
		</div> 
	</div>
	<div class="single-widget widget_categories">
		<h3>categories</h3>
		<div class="widget-cont">
			<ul>
				<li><a href="">Graphic Design</a></li>
				<li><a href="">Web Design and Development</a></li>
				<li><a href="">Photography</a></li>
				<li><a href="">Custom Instruction</a></li>
				<li><a href="">Video Records</a></li>
				<li><a href="">Search Engine Optemigation</a></li>
				<li><a href="">Woocomarce Development</a></li>
			</ul>
		</div> 
	</div>
	<div class="single-widget widget_tag_cloud">
		<h3>Tags Cloud</h3>
		<div class="widget-cont">
			<a href="">Graphic Design</a>
			<a href="">Web Design</a>
			<a href="">Photography</a>
			<a href="">Portfolio</a>
			<a href="">Instruction</a>
			<a href="">Video Records</a>
			<a href="">SEO</a>
			<a href="">ThemeForest</a>
			<a href="">Woocomarce</a> 
		</div> 
	</div>
	<div class="single-widget widget_archive">
		<h3>Tags Cloud</h3>
		<div class="widget-cont">
			<ul>
				<li><a href=""> March 2016</a></li>
				<li><a href=""> February 2016</a></li>
				<li><a href=""> January 2016</a></li>
				<li><a href=""> December 2016</a></li>
				<li><a href=""> November 2016</a></li>
				<li><a href=""> March 2015</a></li>
				<li><a href=""> February 2015</a></li>
				<li><a href=""> January 2015</a></li>
				<li><a href=""> December 2012</a></li>
			</ul>
		</div> 
	</div>
	<div class="single-widget widget_recent_entries">
		<h3 class="widget-title">palash Post</h3>	
		<div class="widget-cont">			
			<ul>
				<li>
					<a href="http://localhost/wordpress/2017/01/16/sumgsang-note-5/">Sumgsang Note 5</a>
					<span class="post-date">January 16, 2017</span>
				</li>
				<li>
					<a href="http://localhost/wordpress/2016/12/24/fgnph-2-2-2-2-2-2/">samsung s7</a>
					<span class="post-date">December 24, 2016</span>
				</li>
				<li>
					<a href="http://localhost/wordpress/2016/12/24/fgnph-2-2-2-2-4/">samsung s7</a>
					<span class="post-date">December 24, 2016</span>
				</li>
				<li>
					<a href="http://localhost/wordpress/2016/12/24/fgnph-3-2-2-4/">samsung s7</a>
					<span class="post-date">December 24, 2016</span>
				</li>
				<li>
					<a href="http://localhost/wordpress/2016/12/24/fgnph-2-3-2-4/">samsung s7</a>
					<span class="post-date">December 24, 2016</span>
				</li>
			</ul>
		</div>
	</div>
-->
</aside>